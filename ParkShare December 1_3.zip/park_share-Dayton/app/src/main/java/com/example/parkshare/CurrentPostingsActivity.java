package com.example.parkshare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CurrentPostingsActivity extends AppCompatActivity {
    private ArrayList<String> postArray;
    public DBHelper dbh;
    public SQLiteDatabase database;
    private PostAdapter messageAdapter;
    private ListView list_view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_postings2);
        postArray = new ArrayList<>();
        list_view = (ListView) findViewById(R.id.current_list);
        messageAdapter = new PostAdapter( this );
        list_view.setAdapter(messageAdapter);

        dbh = new DBHelper(this);
        database = dbh.getWritableDatabase();

        Cursor cursor = database.rawQuery("Select * from posts_table", null);
        cursor.moveToFirst();

        while(cursor.isAfterLast() == false) {
            String add = cursor.getString(cursor.getColumnIndex("Street_Address"));
            Integer id = cursor.getInt(cursor.getColumnIndex("id"));
            Integer taken = cursor.getInt(cursor.getColumnIndex("Taken"));
            cursor.moveToNext();
            String new_id = id.toString();
            String taken_2 = taken.toString();
            if(taken == 0){
                String out = "Address: " + add + "\nPost ID: " + new_id;;

                postArray.add(out);}
        }
        cursor.close();

        list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(CurrentPostingsActivity.this);
                View view1 = LayoutInflater.from(CurrentPostingsActivity.this).inflate(R.layout.dialog_post, null);


                String id2  = messageAdapter.getItem(i);
                int newlin = id2.indexOf("\n");
                int colen = id2.indexOf(" ");
                String actual_add = id2.substring(colen+1,newlin);

                Button doneview = (Button) view1.findViewById(R.id.doneviewing);
                TextView postid = (TextView) view1.findViewById(R.id.postid);
                TextView poststreet = (TextView) view1.findViewById(R.id.poststreetaddress);
                TextView postcityandprov = (TextView) view1.findViewById(R.id.postcityandprovince);
                TextView postpostal = (TextView) view1.findViewById(R.id.postpostalcode);
                TextView postemail = (TextView) view1.findViewById(R.id.posthostemail);
                TextView postphone = (TextView) view1.findViewById(R.id.posthostphone);

                builder.setView(view1);
                builder.create().show();

                Cursor cursor = database.rawQuery("Select * from posts_table where Street_Address = ?" , new String[]{actual_add});
                cursor.moveToFirst();

                String add = cursor.getString(cursor.getColumnIndex("Street_Address"));
                //Toast.makeText(CurrentPostingsActivity.this, add, Toast.LENGTH_SHORT).show();
                Integer id = cursor.getInt(cursor.getColumnIndex("id"));
                String new_id = "Post ID: " + id.toString();
                //Toast.makeText(CurrentPostingsActivity.this, new_id, Toast.LENGTH_SHORT).show();
                Integer host = cursor.getInt(cursor.getColumnIndex("Host_id"));
                String  city  = cursor.getString(cursor.getColumnIndex("City"));
                String  province  = cursor.getString(cursor.getColumnIndex("Province"));
                String citprov = city+" , " + province;
                String  postal  = cursor.getString(cursor.getColumnIndex("Postal_Code"));



                postid.setText(new_id);
                poststreet.setText(add);
                postcityandprov.setText(citprov);
                postpostal.setText(postal);



                doneview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        cursor.close();
                    }
                });
            }
        });





    }

    @SuppressLint("ResourceType")
    public boolean onCreateOptionsMenu(Menu m){
        getMenuInflater().inflate(R.menu.toolbar_menu, m );
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem mi) {
        int mi_id = mi.getItemId();
        switch (mi_id) {

            case R.id.settings:
                Log.d("Toolbar", "About Selected");
                //need to display the author’s name, Activity version number, and instructions for how to use the interface
                AlertDialog.Builder custom = new AlertDialog.Builder(CurrentPostingsActivity.this);
                // Get the layout inflater
                LayoutInflater inflater = CurrentPostingsActivity.this.getLayoutInflater();
                View view = inflater.inflate(R.layout.dialog_help, null);
                custom.setView(view);

                custom.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                AlertDialog customdialog = custom.create();
                custom.show();
                break;

        }
        return true;
    }

    private class PostAdapter extends ArrayAdapter<String> {

        public PostAdapter(Context ctx) {
            super(ctx, 0);
        }

        public int getCount(){
            return postArray.size();
        }

        public String getItem(int position){
            return postArray.get(position);
        }
        public long getItemId(int position){
            Cursor cursor = database.rawQuery("Select * from posts_table", null);
            cursor.moveToPosition(position);
            return cursor.getLong(cursor.getColumnIndex("id"));
        }

        public View getView(int position, View convertView, ViewGroup parent){
            LayoutInflater inflater = CurrentPostingsActivity.this.getLayoutInflater();
            View result = null ;

            result = inflater.inflate(R.layout.postings_list_item, null);


            TextView message = (TextView)result.findViewById(R.id.street_address_textview);
            message.setText(getItem(position));

            return result;

        }



    }
}