package com.example.parkshare;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class CurrentPostingsActivity extends AppCompatActivity {
    private ArrayList<String> postArray;
    public DBHelper dbh;
    public SQLiteDatabase database;
    private PostAdapter messageAdapter;
    private ListView list_view;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_postings2);
        postArray = new ArrayList<>();
        list_view = (ListView) findViewById(R.id.current_list);
        messageAdapter = new PostAdapter( this );
        list_view.setAdapter(messageAdapter);

        dbh = new DBHelper(this);
        database = dbh.getWritableDatabase();

        Cursor cursor = database.rawQuery("Select * from posts_table", null);
        cursor.moveToFirst();

        while(cursor.isAfterLast() == false) {
            String add = cursor.getString(cursor.getColumnIndex("Street_Address"));
            Integer id = cursor.getInt(cursor.getColumnIndex("id"));
            Integer taken = cursor.getInt(cursor.getColumnIndex("Taken"));
            cursor.moveToNext();
            String new_id = id.toString();
            String taken_2 = taken.toString();

            String out = add + ", " + new_id + ", " + taken_2;

            postArray.add(out);
        }
        cursor.close();





        }

    @SuppressLint("ResourceType")
    public boolean onCreateOptionsMenu(Menu m){
        getMenuInflater().inflate(R.menu.toolbar_menu, m );
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem mi) {
        int mi_id = mi.getItemId();
        switch (mi_id) {

            case R.id.settings:
                Log.d("Toolbar", "About Selected");
                //need to display the author’s name, Activity version number, and instructions for how to use the interface
                AlertDialog.Builder custom = new AlertDialog.Builder(CurrentPostingsActivity.this);
                // Get the layout inflater
                LayoutInflater inflater = CurrentPostingsActivity.this.getLayoutInflater();
                View view = inflater.inflate(R.layout.dialog_help, null);
                custom.setView(view);

                custom.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                AlertDialog customdialog = custom.create();
                custom.show();
                break;

        }
        return true;
    }

    private class PostAdapter extends ArrayAdapter<String> {

        public PostAdapter(Context ctx) {
            super(ctx, 0);
        }

        public int getCount(){
            return postArray.size();
        }

        public String getItem(int position){
            return postArray.get(position);
        }
        public long getItemId(int position){
            Cursor cursor = database.rawQuery("Select * from posts_table", null);
            cursor.moveToPosition(position);
            return cursor.getLong(cursor.getColumnIndex("id"));
        }

        public View getView(int position, View convertView, ViewGroup parent){
            LayoutInflater inflater = CurrentPostingsActivity.this.getLayoutInflater();
            View result = null ;

                result = inflater.inflate(R.layout.postings_list_item, null);


            TextView message = (TextView)result.findViewById(R.id.street_address_textview);
            message.setText(getItem(position));

            return result;

        }

    }
}