package com.example.parkshare;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class PostActivity extends AppCompatActivity {

    protected static final String ACTIVITY_NAME = "PostActivity";
    private EditText StreetEditText;
    private EditText CityEditText;
    private EditText ProvinceEditText;
    private EditText PostalCodeEditText;
    private CheckBox AvailabilityBox;
    private Editable StreetInput;
    private Editable CityInput;
    private Editable ProvinceInput;
    private Editable PostalCodeInput;
    private String FullAddress;
    private Boolean Availablenow;
    private Button PostBtn;
    private LatLng PostArea;
    private DBHelper dbh;
    private SQLiteDatabase database;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        Log.i(ACTIVITY_NAME, "In onCreate()");
        StreetEditText = (EditText) findViewById(R.id.postalAddressEditText);
        CityEditText = (EditText) findViewById(R.id.cityEditText);
        ProvinceEditText = (EditText) findViewById(R.id.provinceEditText);
        PostalCodeEditText = (EditText) findViewById(R.id.postalCodeEditText);
        AvailabilityBox = (CheckBox) findViewById(R.id.currentlyAvailableCheckBox);
        PostBtn = (Button) findViewById(R.id.postButton);
        dbh = new DBHelper(this);

        PostBtn.setOnClickListener(new View.OnClickListener() {
            Boolean result;
            @Override
            public void onClick(View view){

                if(!TextUtils.isEmpty(StreetEditText.getText()) && !TextUtils.isEmpty(CityEditText.getText()) && !TextUtils.isEmpty(ProvinceEditText.getText()) && !TextUtils.isEmpty(PostalCodeEditText.getText())){
                    StreetInput = StreetEditText.getText();
                    CityInput = CityEditText.getText();
                    ProvinceInput = ProvinceEditText.getText();
                    PostalCodeInput = PostalCodeEditText.getText();
                    FullAddress = StreetInput +", " + CityInput + ", " + ProvinceInput + ", " + PostalCodeInput;


                    PostArea = getLocationFromAddress(PostActivity.this, FullAddress);

                    if(AvailabilityBox.isChecked() == true){
                        result = insertData(StreetInput.toString(),CityInput.toString(),ProvinceInput.toString(),PostalCodeInput.toString(),0, PostArea.latitude, PostArea.longitude);
                    }

                    else {
                        result = insertData(StreetInput.toString(), CityInput.toString(), ProvinceInput.toString(), PostalCodeInput.toString(), 1, PostArea.latitude, PostArea.longitude);
                    }



                    //Snackbar snack = Snackbar.make(view,result.toString(),Snackbar.LENGTH_LONG);
                    //snack.show();

                    Intent intent;
                    intent = new Intent(PostActivity.this, MainActivity.class);
                    startActivity(intent);


                }

            }
        });
    }

    public LatLng getLocationFromAddress(Context context, String FullAddress) {

        Geocoder coder = new Geocoder(context);
        List<Address> address;
        LatLng postlocation = null;

        try {
            address = coder.getFromLocationName(FullAddress, 1);
            if (address == null) {
                return null;
            }
            Address location = address.get(0);
            location.getLatitude();
            location.getLongitude();

            postlocation = new LatLng(location.getLatitude(), location.getLongitude() );

        } catch (Exception ex) {

            ex.printStackTrace();
        }

        return postlocation;
    }



    @SuppressLint("ResourceType")
    public boolean onCreateOptionsMenu(Menu m){
        getMenuInflater().inflate(R.menu.toolbar_menu, m );
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem mi) {
        int mi_id = mi.getItemId();
        switch (mi_id) {

            case R.id.settings:
                Log.d("Toolbar", "About Selected");
                //need to display the author’s name, Activity version number, and instructions for how to use the interface
                AlertDialog.Builder custom = new AlertDialog.Builder(PostActivity.this);
                // Get the layout inflater
                LayoutInflater inflater = PostActivity.this.getLayoutInflater();
                View view = inflater.inflate(R.layout.dialog_help_post, null);
                custom.setView(view);

                custom.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });

                AlertDialog customdialog = custom.create();
                custom.show();
                break;

        }
        return true;
    }

    public boolean insertData(String street, String city, String province, String postal, Integer taken, Double Lat, Double Long) {
        database = dbh.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Host_id", LoginActivity.ActiveID);
        values.put("Street_Address", street);
        values.put("Lat", Lat);
        values.put("Long", Long);
        values.put("Province",province);
        values.put("City", city);
        values.put("Postal_Code", postal);
        values.put("Taken", taken);
        long result = database.insert(DBHelper.POSTTABLE_NAME, null, values);
        if (result == -1)
            return false;
        else
            return true;
    }
}

