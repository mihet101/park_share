package com.example.parkshare;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PostActivity extends AppCompatActivity {
    private Button selectAvailabilityButton;
    //private CalendarView mCalendarView = findViewById(R.id.calendarView);

    private EditText startDate;
    private EditText endDate;
    private EditText startTime;
    private EditText endTime;
    private Button addDayButton;
    private String startDateString;
    private String endDateString;
    private String startTimeString;
    private String endTimeString;
    public List<String> startDates = new ArrayList<String>();
    public List<String> endDates = new ArrayList<String>();

    public List<String> startTimes = new ArrayList<String>();
    public List<String> endTimes = new ArrayList<String>();
    protected static final String ACTIVITY_NAME = "PostActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        Log.i(ACTIVITY_NAME, "In onCreate()");
        //mCalendarView = (CalendarView) findViewById(R.id.calendarView);
        //selectAvailabilityButton = (Button)findViewById(R.id.selectAvailabilityButton);
        //addDayButton = (Button)findViewById(R.id.addDayButton);

    }

    public void selectAvailabilityButtonClicked(View v) {

        //open dialog box with calendar view
        AlertDialog.Builder custom = new AlertDialog.Builder(PostActivity.this);
        // Get the layout inflater
        LayoutInflater inflater = PostActivity.this.getLayoutInflater();
        View view2 = inflater.inflate(R.layout.dialog_calendar, null);
        custom.setView(view2);

        /**
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                date = (i1+1) + "/" + i2 + "/" + i;
                Log.d(ACTIVITY_NAME, "onSelectedDayChange: Date mm/dd/yyyy: " + date);
            }
        });

        addDayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //add the currently selected day on the calendar to the available dates array
                dates.add(date);
            }
        });
         */










        startDate = findViewById(R.id.startDateEditText);
        endDate = (EditText)v.findViewById(R.id.endDateEditText);
        startTime = (EditText)v.findViewById(R.id.startTimeEditText);
        endTime = (EditText)v.findViewById(R.id.endTimeEditText);

        custom.setPositiveButton(R.string.doneCalendar, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {

                startDateString = startDate.getText().toString();
                endDateString = endDate.getText().toString();
                startTimeString = startTime.getText().toString();
                endTimeString = endTime.getText().toString();

                startDates.add(startDateString);
                startTimes.add(startTimeString);
                endDates.add(endDateString);
                endTimes.add(endTimeString);
                Log.d(ACTIVITY_NAME, "Start date" + startDateString);

            }
        });

        custom.setNegativeButton(R.string.cancelCalendar, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //user cancelled the dialog
            }
        });

        AlertDialog customdialog = custom.create();
        custom.show();

    }



}

