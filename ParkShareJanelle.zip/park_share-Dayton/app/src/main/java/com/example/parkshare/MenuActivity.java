package com.example.parkshare;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
    public void MyAccountClicked(View v) {
        Intent intent = new Intent(MenuActivity.this, AccountActivity.class);
        startActivity(intent);
    }
    public void MyPostingsClicked(View v) {
        Intent intent = new Intent(MenuActivity.this, MyPostingsActivity.class);
        startActivity(intent);
    }
    public void MyRentsClicked(View v) {
        Intent intent = new Intent(MenuActivity.this, CurrentPostingsActivity.class);
        startActivity(intent);
    }
    public void LogoutClicked(View v) {
        Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}