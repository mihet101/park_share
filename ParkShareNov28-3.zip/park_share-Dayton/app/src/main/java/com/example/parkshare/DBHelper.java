package com.example.parkshare;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {


    private Context context;
    public static final String DATABASE_NAME = "Login.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_NAME = "user_table";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_FIRSTNAME = "First_Name";
    public static final String COLUMN_LASTNAME = "Last_Name";
    public static final String COLUMN_PASSWORD = "Password";
    public static final String COLUMN_EMAIL = "Email";
    public static final String COLUMN_Phonenum = "Phone_num";
    public static final String POSTTABLE_NAME = "posts_table";
    public static final String COLUMN_POSTID = "id";
    public static final String COLUMN_HOSTID = "Host_id";
    public static final String COLUMN_STREET = "Street_Address";
    public static final String COLUMN_CITY = "City";
    public static final String COLUMN_PROVINCE = "Province";
    public static final String COLUMN_POSTALCODE = "Postal_Code";
    public static final String COLUMN_TAKEN = "Taken";
    public static final String POSTINGSTABLE_NAME = "postings_table";


    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String userquery =
                "CREATE TABLE " + TABLE_NAME +
                        " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_FIRSTNAME + " TEXT, " +
                        COLUMN_LASTNAME + " TEXT, " +
                        COLUMN_PASSWORD + " TEXT, " +
                        COLUMN_EMAIL + " TEXT, " +
                        COLUMN_Phonenum + " TEXT);";

        String postquery =
                "CREATE TABLE " + POSTTABLE_NAME +
                        " (" + COLUMN_POSTID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_HOSTID + " INTEGER, " +
                        COLUMN_STREET + " TEXT, " +
                        COLUMN_CITY + " TEXT, " +
                        COLUMN_PROVINCE + " TEXT, " +
                        COLUMN_POSTALCODE + " TEXT, " +
                        COLUMN_TAKEN + " BOOLEAN, " +
                        " FOREIGN KEY (" + COLUMN_HOSTID + ") REFERENCES " + TABLE_NAME + "(" + COLUMN_ID + "));";

        String postingsquery =
                "CREATE TABLE " + POSTINGSTABLE_NAME +
                        " (" + COLUMN_POSTID + " INTEGER , " +
                        COLUMN_HOSTID + " INTEGER, " +
                        " FOREIGN KEY (" + COLUMN_POSTID + ") REFERENCES " + POSTTABLE_NAME + "(" + COLUMN_POSTID + "), " +
                        " FOREIGN KEY (" + COLUMN_HOSTID + ") REFERENCES " + POSTTABLE_NAME + "(" + COLUMN_HOSTID + "));";

        db.execSQL(userquery);
        db.execSQL(postquery);
        db.execSQL(postingsquery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + POSTTABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + POSTINGSTABLE_NAME);
        onCreate(db);

    }
}